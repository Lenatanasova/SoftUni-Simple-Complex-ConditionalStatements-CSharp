﻿string typeMovie = Console.ReadLine();
int rowsCount = int.Parse(Console.ReadLine());
int seatsPerRow = int.Parse(Console.ReadLine());


int totalSeatsCount = rowsCount * seatsPerRow;
double price = 0;

if (typeMovie == "Normal")
{
    price = 7.50;
}
else if (typeMovie == "Premiere")
{
    price = 12.00;
}
else if (typeMovie == "Discount")
{
    price = 5.00;
}

double totalPrice = totalSeatsCount * price;
Console.WriteLine($"{totalPrice:f2}");
