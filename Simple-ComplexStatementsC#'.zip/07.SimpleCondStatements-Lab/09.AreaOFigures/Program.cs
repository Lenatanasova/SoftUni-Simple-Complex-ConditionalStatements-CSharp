﻿string figureType = Console.ReadLine();

if (figureType == "square")
{
    double side = double.Parse(Console.ReadLine());
    double areaSquare = side * side;
    Console.WriteLine($"{areaSquare:f2}");
}
else if (figureType == "rectangle")
{
    double width = double.Parse(Console.ReadLine());
    double length = double.Parse(Console.ReadLine());
    double areaRectangle = width * length;
    Console.WriteLine($"{areaRectangle:f2}");
}
else if (figureType == "circle")
{
    double radius = double.Parse(Console.ReadLine());
    double areaCircle = Math.PI * radius * radius;
    Console.WriteLine($"{areaCircle:f2}");
}
