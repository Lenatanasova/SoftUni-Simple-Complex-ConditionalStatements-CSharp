﻿string drinkType = Console.ReadLine();
string extra = Console.ReadLine();

double priceCoffee = 1.00;
double priceTea = 0.60;
double priceSugar = 0.40;

if (drinkType == "coffee" && extra == "sugar")
{
    Console.WriteLine($"Final price: ${priceCoffee + priceSugar:f2}");
}
else if (drinkType == "coffee" && extra == "no")
{
    Console.WriteLine($"Final price: ${priceCoffee:f2}");
}
if (drinkType == "tea" && extra == "sugar")
{
    Console.WriteLine($"Final price: ${priceTea + priceSugar:f2}");
}
else if (drinkType == "tea" && extra == "no")
{
    Console.WriteLine($"Final price: ${priceTea:f2}");
}