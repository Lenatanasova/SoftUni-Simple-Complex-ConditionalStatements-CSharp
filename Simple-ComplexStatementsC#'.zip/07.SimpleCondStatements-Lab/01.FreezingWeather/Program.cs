﻿

int temperature = int.Parse(Console.ReadLine());

if(temperature <= 0)
{
    Console.WriteLine("Freezing weather!");
}
