﻿int number = int.Parse(Console.ReadLine());

if (number == 0)
{
    Console.WriteLine("zero");
}
else if (number < 0)
{
    Console.WriteLine("negative");
}
else
{
    Console.WriteLine("positive");
}