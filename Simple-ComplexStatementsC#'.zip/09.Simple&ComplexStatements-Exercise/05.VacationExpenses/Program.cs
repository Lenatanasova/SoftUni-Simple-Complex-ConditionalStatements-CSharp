﻿
string season = Console.ReadLine();
string accommodationType = Console.ReadLine();
int daysCount = int.Parse(Console.ReadLine());

double pricePerDay = 0;
double discount = 0;


switch (season)
{
    case "Spring":
        if (accommodationType == "Hotel")
        {
            pricePerDay = 30;
        }
        else if (accommodationType == "Camping")
        {
            pricePerDay = 10;
        }
        discount = 0.20;
        break;
    case "Summer":
        if (accommodationType == "Hotel")
        {
            pricePerDay = 50;
        }
        else if (accommodationType == "Camping")
        {
            pricePerDay = 30;
        }
        break;
    case "Autumn":
        if (accommodationType == "Hotel")
        {
            pricePerDay = 20;
        }
        else if (accommodationType == "Camping")
        {
            pricePerDay = 15;
        }
        discount = 0.30;
        break;
    case "Winter":
        if (accommodationType == "Hotel")
        {
            pricePerDay = 40;
        }
        else if (accommodationType == "Camping")
        {
            pricePerDay = 10;
        }
        discount = 0.10;
        break;

       
}
double totalPrice = daysCount * pricePerDay;
double totalDiscount = totalPrice * discount;
double finalPrice = totalPrice - totalDiscount;

Console.WriteLine($"{finalPrice:f2}");
