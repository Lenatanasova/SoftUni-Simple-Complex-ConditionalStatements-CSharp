﻿double a = double.Parse(Console.ReadLine());
double b = double.Parse(Console.ReadLine());
string math = Console.ReadLine();

switch (math)
{
    case "+":
        Console.WriteLine($"{a} {math} {b} = {a+b:f2}");
        break;
    case "-":
        Console.WriteLine($"{a} {math} {b} = {a - b:f2}");
        break;
    case "*":
        Console.WriteLine($"{a} {math} {b} = {a * b:f2}");
        break;
    case "/":
        Console.WriteLine($"{a} {math} {b} = {a / b:f2}");
        break;

}