﻿double a = double.Parse(Console.ReadLine());
double b = double.Parse(Console.ReadLine());
double c = double.Parse(Console.ReadLine());

if (a * b * c > 0)
{
    Console.WriteLine("positive");
}
else if (a * b * c < 0)
{
    Console.WriteLine("negative");
}
else
{
    Console.WriteLine("zero");
}